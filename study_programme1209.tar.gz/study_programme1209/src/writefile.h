#ifndef WRITEFILE_H
#define WRITEFILE_H

#include <QtGui>

class WriteFile:public QGraphicsWidget
{
public:
    WriteFile(QGraphicsItem *parent = 0);
    ~WriteFile();
};

#endif // WRITEFILE_H
