#ifndef READFILE_H
#define READFILE_H

#include <QtGui>

class ReadFile:public QGraphicsWidget
{
public:
    ReadFile(QGraphicsItem *parent = 0);
    ~ReadFile();

};

#endif // READFILE_H
