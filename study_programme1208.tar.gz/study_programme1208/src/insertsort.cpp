#include "insertsort.h"

InsertSort::InsertSort()
{

}


InsertSort::~InsertSort ()
{

}
