#include <iostream>

using namespace std;

class InsertSort
{
public:
    InsertSort();
    ~InsertSort();

};
